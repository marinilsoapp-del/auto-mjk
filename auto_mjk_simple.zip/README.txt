Auto MJK - Versão simples
Abra index.html no navegador para usar. Dados são salvos localmente no navegador (localStorage).
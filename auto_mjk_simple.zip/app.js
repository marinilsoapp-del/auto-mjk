// Auto MJK - Simplified app (no backend). Stores data in localStorage.
const STORAGE_KEY = 'auto_mjk_data_v1';

let state = {
  cars: [],
  selectedCarIndex: 0,
  fuels: [], // {carIndex, date, km, liters, total}
  services: [] // {carIndex, date, km, service, cost, note}
};

function save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function load() { const s = localStorage.getItem(STORAGE_KEY); if (s) state = JSON.parse(s); else { initSample(); save(); } }

function initSample() {
  state.cars = [ {name:'Hyundai i30', plate:'ABC-1234'}, {name:'Carro 2', plate:''} ];
  state.selectedCarIndex = 0;
  state.fuels = [];
  state.services = [];
}

function $(sel){ return document.querySelector(sel); }
function $all(sel){ return Array.from(document.querySelectorAll(sel)); }

function renderCarSelect(){
  const sel = $('#carSelect');
  sel.innerHTML = '';
  state.cars.forEach((c, i)=>{
    const opt = document.createElement('option');
    opt.value = i; opt.textContent = `${c.name}${c.plate? ' — ' + c.plate : ''}`;
    sel.appendChild(opt);
  });
  sel.value = state.selectedCarIndex || 0;
  sel.onchange = ()=> { state.selectedCarIndex = parseInt(sel.value); save(); renderMain(); }
}

function openModal(){ $('#modal').classList.remove('hidden'); renderCarsList(); }
function closeModal(){ $('#modal').classList.add('hidden'); }

function renderCarsList(){
  const container = $('#carsList'); container.innerHTML='';
  state.cars.forEach((c,i)=>{
    const div = document.createElement('div'); div.style.display='flex'; div.style.justifyContent='space-between'; div.style.alignItems='center'; div.style.marginBottom='8px';
    const left = document.createElement('div'); left.innerHTML = `<strong>${c.name}</strong><div class="small-muted">${c.plate||''}</div>`;
    const btns = document.createElement('div');
    const del = document.createElement('button'); del.textContent='Remover'; del.className='secondary'; del.onclick=()=>{ state.cars.splice(i,1); if(state.selectedCarIndex>=state.cars.length) state.selectedCarIndex=0; save(); renderCarSelect(); renderCarsList(); };
    btns.appendChild(del);
    div.appendChild(left); div.appendChild(btns);
    container.appendChild(div);
  });
}

function addCar(){
  const name = $('#newCarName').value.trim(); const plate = $('#newCarPlate').value.trim();
  if(!name) { alert('Informe o nome do veículo'); return; }
  if(state.cars.length>=4){ alert('Limite de 4 veículos.'); return; }
  state.cars.push({name, plate}); save(); renderCarSelect(); renderCarsList();
  $('#newCarName').value=''; $('#newCarPlate').value='';
}

function renderMain(){
  const main = $('#main'); main.innerHTML='';
  const view = document.querySelector('.tab.active').dataset.view;
  if(view==='dashboard') renderDashboard(main);
  else if(view==='fuel') renderFuelForm(main);
  else if(view==='service') renderServiceForm(main);
  else if(view==='history') renderHistory(main);
  else if(view==='export') renderExport(main);
}

function renderDashboard(root){
  const c = state.cars[state.selectedCarIndex];
  const card = document.createElement('div'); card.className='card';
  card.innerHTML = `<h2>${c? c.name : '—'}</h2>`;
  const lastFuel = [...state.fuels].reverse().find(f=>f.carIndex===state.selectedCarIndex);
  const avg = calcAvgConsumption(state.selectedCarIndex);
  card.innerHTML += `<p>Último abastecimento: ${lastFuel? lastFuel.date : '—'}</p>`;
  card.innerHTML += `<p>Consumo médio: ${avg? avg.toFixed(1)+' km/l' : '—'}</p>`;
  const monthly = calcMonthlyCost(state.selectedCarIndex);
  card.innerHTML += `<p>Gasto no mês: R$ ${monthly.toFixed(2)}</p>`;
  root.appendChild(card);

  // Upcoming maintenance (simple check: services older than 6000 km suggest)
  const lastService = [...state.services].reverse().find(s=>s.carIndex===state.selectedCarIndex);
  const alert = document.createElement('div'); alert.className='card';
  if(lastService){
    alert.innerHTML = `<strong>Última manutenção:</strong> ${lastService.service} em ${lastService.km} km`;
    if(lastService.km && avg){
      const kmNext = lastService.km + 5000;
      alert.innerHTML += `<div class="alert">Próxima manutenção recomendada em ${kmNext} km</div>`;
    }
  } else {
    alert.innerHTML = `<strong>Sem registros de manutenção.</strong>`;
  }
  root.appendChild(alert);
}

function renderFuelForm(root){
  const card = document.createElement('div'); card.className='card';
  card.innerHTML = `
    <h3>Registrar abastecimento</h3>
    <label class="form-label">Data <input id="f_date" type="date"></label>
    <label class="form-label">KM atual <input id="f_km" type="number" min="0"></label>
    <label class="form-label">Litros <input id="f_liters" type="number" step="0.01"></label>
    <label class="form-label">Valor total (R$) <input id="f_total" type="number" step="0.01"></label>
    <div class="row"><button id="saveFuel">Salvar</button></div>
  `;
  root.appendChild(card);
  $('#saveFuel').onclick = ()=>{
    const date = $('#f_date').value || new Date().toISOString().slice(0,10);
    const km = parseFloat($('#f_km').value); const liters = parseFloat($('#f_liters').value); const total = parseFloat($('#f_total').value);
    if(isNaN(km) || isNaN(liters) || isNaN(total)){ alert('Preencha todos os campos'); return; }
    state.fuels.push({carIndex: state.selectedCarIndex, date, km, liters, total});
    save(); alert('Abastecimento salvo'); renderMain();
  }
}

function renderServiceForm(root){
  const card = document.createElement('div'); card.className='card';
  card.innerHTML = `
    <h3>Registrar manutenção</h3>
    <label class="form-label">Data <input id="s_date" type="date"></label>
    <label class="form-label">KM atual <input id="s_km" type="number" min="0"></label>
    <label class="form-label">Serviço <input id="s_name"></label>
    <label class="form-label">Custo (R$) <input id="s_cost" type="number" step="0.01"></label>
    <label class="form-label">Observações <input id="s_note"></label>
    <div class="row"><button id="saveService">Salvar</button></div>
  `;
  root.appendChild(card);
  $('#saveService').onclick = ()=>{
    const date = $('#s_date').value || new Date().toISOString().slice(0,10);
    const km = parseFloat($('#s_km').value); const service = $('#s_name').value.trim(); const cost = parseFloat($('#s_cost').value)||0; const note = $('#s_note').value;
    if(isNaN(km) || !service){ alert('Preencha KM e nome do serviço'); return; }
    state.services.push({carIndex: state.selectedCarIndex, date, km, service, cost, note});
    save(); alert('Manutenção salva'); renderMain();
  }
}

function renderHistory(root){
  const card = document.createElement('div'); card.className='card';
  card.innerHTML = `<h3>Histórico de abastecimentos</h3>`;
  const table = document.createElement('table'); table.className='table';
  const thead = document.createElement('thead'); thead.innerHTML = '<tr><th>Data</th><th>KM</th><th>Litros</th><th>Valor</th></tr>'; table.appendChild(thead);
  const tbody = document.createElement('tbody');
  state.fuels.filter(f=>f.carIndex===state.selectedCarIndex).sort((a,b)=> b.km - a.km).forEach(f=>{
    const tr = document.createElement('tr'); tr.innerHTML = `<td>${f.date}</td><td>${f.km}</td><td>${f.liters}</td><td>R$ ${f.total.toFixed(2)}</td>`;
    tbody.appendChild(tr);
  });
  table.appendChild(tbody); card.appendChild(table);
  // services
  const svc = document.createElement('div'); svc.className='card'; svc.innerHTML = '<h3>Histórico de manutenções</h3>';
  const t2 = document.createElement('table'); t2.className='table'; t2.innerHTML = '<thead><tr><th>Data</th><th>KM</th><th>Serviço</th><th>Custo</th></tr></thead>';
  const b2 = document.createElement('tbody');
  state.services.filter(s=>s.carIndex===state.selectedCarIndex).sort((a,b)=> b.km - a.km).forEach(s=>{
    const tr = document.createElement('tr'); tr.innerHTML = `<td>${s.date}</td><td>${s.km}</td><td>${s.service}</td><td>R$ ${s.cost.toFixed(2)}</td>`;
    b2.appendChild(tr);
  });
  t2.appendChild(b2); svc.appendChild(t2);
  root.appendChild(card); root.appendChild(svc);
}

function calcAvgConsumption(carIndex){
  const items = state.fuels.filter(f=>f.carIndex===carIndex).sort((a,b)=> a.km - b.km);
  if(items.length<2) return null;
  let totalKm = 0, totalLiters=0;
  for(let i=1;i<items.length;i++){
    totalKm += (items[i].km - items[i-1].km);
    totalLiters += items[i].liters;
  }
  if(totalLiters===0) return null;
  return totalKm / totalLiters;
}

function calcMonthlyCost(carIndex){
  const now = new Date(); const month = now.getMonth(); const year = now.getFullYear();
  const items = state.fuels.filter(f=> f.carIndex===carIndex && new Date(f.date).getMonth()===month && new Date(f.date).getFullYear()===year);
  return items.reduce((s,i)=> s + (i.total||0), 0);
}

function renderExport(root){
  const card = document.createElement('div'); card.className='card';
  card.innerHTML = `<h3>Exportar dados CSV</h3><p class="small-muted">Você pode exportar todos os dados dos veículos.</p><div class="row"><button id="exportBtn">Exportar CSV</button></div>`;
  root.appendChild(card);
  $('#exportBtn').onclick = ()=>{
    const csv = generateCSV();
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'auto_mjk_data.csv'; document.body.appendChild(a); a.click(); a.remove();
  }
}

function generateCSV(){
  const lines = [];
  lines.push('type,carIndex,carName,date,km,liters,total,service,cost,note');
  state.fuels.forEach(f=> lines.push(`fuel,${f.carIndex},${state.cars[f.carIndex].name},${f.date},${f.km},${f.liters},${f.total},,,`));
  state.services.forEach(s=> lines.push(`service,${s.carIndex},${state.cars[s.carIndex].name},${s.date},${s.km},,,${s.service},${s.cost},${s.note||''}`));
  return lines.join('\\n');
}

// Initialize
document.addEventListener('DOMContentLoaded', ()=>{
  load();
  renderCarSelect();
  renderMain();

  // events
  $('#manageCarsBtn').onclick = openModal;
  $('#closeModal').onclick = closeModal;
  $('#addCarBtn').onclick = addCar;
  $all('.tab').forEach(btn=> btn.onclick = ()=>{
    $all('.tab').forEach(b=> b.classList.remove('active')); btn.classList.add('active'); renderMain();
  });
});